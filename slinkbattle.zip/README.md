# SlinkBattle

Clone multiplayer do slither.io para uso privado.

## Instalação

```bash
cp .env.example .env
npm install
node server/server.js
```

## Configuração

Edite o arquivo `.env` para personalizar o servidor.

## Acesso

Abra o navegador em `http://localhost:8080`.

## Licença

Uso privado e educacional. Não destinado à redistribuição pública.